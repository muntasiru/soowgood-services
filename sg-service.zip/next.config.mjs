/** @type {import('next').NextConfig} */
const nextConfig = {
  runtime: "edge",
};

export default nextConfig;
