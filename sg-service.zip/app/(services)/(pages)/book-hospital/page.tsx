const Page = () => {
  return <>hOSPITAL</>;
};

export default Page;
